const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const { connectDB } = require("./src/db");
const User = require("./src/models/User");
const LoginHistory = require("./src/models/LoginHistory");
const Guardian = require("./src/models/Guardian");
const EmailVerify = require("./src/models/EmailVerify");
const { sendVerifyMail } = require("./src/utils/mailer");

const app = express();
app.use(express.json());

// =======================
// JWT 설정
// =======================
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret";
const ACCESS_EXPIRES_IN = "15m";
const REFRESH_EXPIRES_IN = "14d";

// =======================
// 공통: IP / 기기정보(user-agent) 얻기
// =======================
function getClientInfo(req) {
  const ip =
    (req.headers["x-forwarded-for"]?.toString().split(",")[0] || "").trim() ||
    req.socket?.remoteAddress ||
    "";
  const userAgent = req.headers["user-agent"] || "";
  return { ip, userAgent };
}

// =======================
// 인증 미들웨어
// =======================
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ ok: false, message: "missing token" });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch {
    return res.status(401).json({ ok: false, message: "invalid token" });
  }
}

// =======================
// ownerId 계산 (가정 기준 묶기)
// =======================
async function resolveOwnerIdForUser(userId) {
  const owner = await Guardian.findOne({ memberId: userId, role: "OWNER" });
  if (owner) return owner.ownerId;

  const sub = await Guardian.findOne({ memberId: userId, role: "SUB" });
  if (sub) return sub.ownerId;

  return userId;
}

// =======================
// OWNER 권한 체크 미들웨어
// - "내가 내 가정의 OWNER냐?" 확인
// =======================
async function requireOwner(req, res, next) {
  const isOwner = await Guardian.findOne({
    ownerId: req.userId,
    memberId: req.userId,
    role: "OWNER",
  });
  if (!isOwner) return res.status(403).json({ ok: false, message: "owner only" });
  next();
}

// =======================
// Health
// =======================
app.get("/health", (req, res) => res.json({ ok: true }));

// (테스트용) 내 ownerId 확인
app.get("/me", auth, async (req, res) => {
  const ownerId = await resolveOwnerIdForUser(req.userId);
  res.json({ ok: true, userId: req.userId, ownerId });
});

// =======================
// 1️⃣ 이메일 인증 요청 (User 생성 ❌)
// body: { email }
// =======================
app.post("/auth/request-verify", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ ok: false, message: "email required" });

    const normalizedEmail = email.toLowerCase().trim();

    // 이미 가입된 이메일 차단
    if (await User.findOne({ email: normalizedEmail })) {
      return res.status(409).json({ ok: false, message: "email exists" });
    }

    // 기존 인증코드 제거
    await EmailVerify.deleteMany({ email: normalizedEmail });

    const code = Math.floor(100000 + Math.random() * 900000).toString();

    // EmailVerify 스키마에 verified가 없으면 아래 verified는 빼도 됨
    await EmailVerify.create({
      email: normalizedEmail,
      code,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000),
      verified: false,
    });

    await sendVerifyMail(normalizedEmail, code);
    return res.json({ ok: true });
  } catch (e) {
    console.error("request-verify error:", e);
    return res.status(500).json({ ok: false, message: e.message });
  }
});

// =======================
// 1️⃣ 이메일 인증 확인
// body: { email, code }
// =======================
app.post("/auth/verify", async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) return res.status(400).json({ ok: false, message: "missing fields" });

    const normalizedEmail = email.toLowerCase().trim();

    const record = await EmailVerify.findOne({
      email: normalizedEmail,
      code,
      expiresAt: { $gt: new Date() },
    });

    if (!record) {
      return res.status(400).json({ ok: false, message: "invalid or expired code" });
    }

    await EmailVerify.updateOne({ _id: record._id }, { $set: { verified: true } });
    return res.json({ ok: true });
  } catch (e) {
    console.error("verify error:", e);
    return res.status(500).json({ ok: false, message: e.message });
  }
});

// =======================
// 1️⃣ 회원가입 (인증 완료 후만 가능)
// body: { email, username, password, consent:true }
// =======================
app.post("/auth/signup", async (req, res) => {
  try {
    const { email, username, password, consent } = req.body;
    if (!email || !username || !password || consent !== true) {
      return res.status(400).json({ ok: false, message: "missing fields" });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const normalizedUsername = username.toLowerCase().trim();

    const verified = await EmailVerify.findOne({
      email: normalizedEmail,
      verified: true,
    });
    if (!verified) {
      return res.status(403).json({ ok: false, message: "email not verified" });
    }

    // 이메일/아이디 중복 체크
    if (await User.findOne({ email: normalizedEmail })) {
      return res.status(409).json({ ok: false, message: "email exists" });
    }
    if (await User.findOne({ username: normalizedUsername })) {
      return res.status(409).json({ ok: false, message: "username exists" });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const user = await User.create({
      email: normalizedEmail,
      username: normalizedUsername,
      passwordHash,
      verified: true,
      consentAt: new Date(),
    });

    // 가입하면 본인 가정 생성: OWNER 등록
    await Guardian.create({
      ownerId: user._id,
      memberId: user._id,
      role: "OWNER",
    });

    // 인증 레코드 정리
    await EmailVerify.deleteMany({ email: normalizedEmail });

    return res.status(201).json({ ok: true, userId: user._id });
  } catch (e) {
    console.error("signup error:", e);
    return res.status(500).json({ ok: false, message: e.message });
  }
});

// =======================
// 1️⃣ 로그인 (아이디만)
// body: { username, password }
// + 로그인한 IP/기기정보 저장
// =======================
app.post("/auth/login", async (req, res) => {
  const { ip, userAgent } = getClientInfo(req);

  try {
    const { username, password } = req.body;
    if (!username || !password) {
      await LoginHistory.create({
        userId: null,
        usernameTried: "",
        ip,
        userAgent,
        success: false,
        reason: "MISSING_FIELDS",
      }).catch(() => {});
      return res.status(400).json({ ok: false, message: "missing fields" });
    }

    const normalizedUsername = username.toLowerCase().trim();
    const user = await User.findOne({ username: normalizedUsername });

    if (!user) {
      await LoginHistory.create({
        userId: null,
        usernameTried: normalizedUsername,
        ip,
        userAgent,
        success: false,
        reason: "NO_USER",
      }).catch(() => {});
      return res.status(401).json({ ok: false, message: "invalid credentials" });
    }

    const ok = await bcrypt.compare(password, user.passwordHash);
    if (!ok) {
      await LoginHistory.create({
        userId: user._id,
        usernameTried: user.username,
        ip,
        userAgent,
        success: false,
        reason: "BAD_PASSWORD",
      }).catch(() => {});
      return res.status(401).json({ ok: false, message: "invalid credentials" });
    }

    const accessToken = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: ACCESS_EXPIRES_IN });
    const refreshToken = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: REFRESH_EXPIRES_IN });

    await LoginHistory.create({
      userId: user._id,
      usernameTried: user.username,
      ip,
      userAgent,
      success: true,
      reason: "OK",
    }).catch(() => {});

    return res.json({ ok: true, accessToken, refreshToken });
  } catch (e) {
    console.error("login error:", e);
    await LoginHistory.create({
      userId: null,
      usernameTried: req.body?.username ? String(req.body.username) : "",
      ip,
      userAgent,
      success: false,
      reason: "SERVER_ERROR",
    }).catch(() => {});
    return res.status(500).json({ ok: false, message: "server error" });
  }
});

// =======================
// 자동 로그인 (refresh -> access 재발급)
// body: { refreshToken }
// =======================
app.post("/auth/refresh", (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) return res.status(400).json({ ok: false, message: "missing refreshToken" });

    const decoded = jwt.verify(refreshToken, JWT_SECRET);
    const accessToken = jwt.sign({ userId: decoded.userId }, JWT_SECRET, { expiresIn: ACCESS_EXPIRES_IN });

    return res.json({ ok: true, accessToken });
  } catch {
    return res.status(401).json({ ok: false, message: "invalid refreshToken" });
  }
});

// =======================================================
// 2️⃣ 관리자 권한 기능 (OWNER + SUB 2명 공유)
// =======================================================

// 2-1) 보호자 목록 (OWNER/SUB 모두 가능)
app.get("/guardians", auth, async (req, res) => {
  try {
    const ownerId = await resolveOwnerIdForUser(req.userId);

    const list = await Guardian.find({ ownerId }).lean();
    const memberIds = list.map((g) => g.memberId);

    const users = await User.find({ _id: { $in: memberIds } }, { email: 1, username: 1 }).lean();
    const map = new Map(users.map((u) => [String(u._id), { email: u.email, username: u.username }]));

    return res.json({
      ok: true,
      ownerId,
      guardians: list.map((g) => ({
        memberId: g.memberId,
        role: g.role,
        email: map.get(String(g.memberId))?.email || "",
        username: map.get(String(g.memberId))?.username || "",
      })),
    });
  } catch (e) {
    console.error("guardians list error:", e);
    return res.status(500).json({ ok: false, message: "server error" });
  }
});

// 2-2) 보조 보호자 추가 (OWNER만 가능, 총 2인 제한)
app.post("/guardians/add", auth, requireOwner, async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ ok: false, message: "email required" });

    const normalizedEmail = email.toLowerCase().trim();
    const target = await User.findOne({ email: normalizedEmail });
    if (!target) return res.status(404).json({ ok: false, message: "user not found" });

    // 자기 자신 추가 방지
    if (String(target._id) === String(req.userId)) {
      return res.status(400).json({ ok: false, message: "cannot add self" });
    }

    // 이미 등록돼 있는지
    const already = await Guardian.findOne({ ownerId: req.userId, memberId: target._id });
    if (already) return res.status(409).json({ ok: false, message: "already guardian" });

    // 총 2인 제한 (OWNER 1 + SUB 1)
    const count = await Guardian.countDocuments({ ownerId: req.userId });
    if (count >= 2) return res.status(400).json({ ok: false, message: "max 2 guardians" });

    await Guardian.create({
      ownerId: req.userId,
      memberId: target._id,
      role: "SUB",
    });

    return res.json({ ok: true });
  } catch (e) {
    console.error("guardians add error:", e);
    return res.status(500).json({ ok: false, message: "server error" });
  }
});

// 2-3) 보조 보호자 삭제 (OWNER만 가능)
app.delete("/guardians/remove/:memberId", auth, requireOwner, async (req, res) => {
  try {
    const memberId = req.params.memberId;

    // OWNER 본인 삭제 불가
    if (String(memberId) === String(req.userId)) {
      return res.status(400).json({ ok: false, message: "cannot remove owner" });
    }

    const r = await Guardian.deleteOne({
      ownerId: req.userId,
      memberId,
      role: "SUB",
    });

    return res.json({ ok: true, deleted: r.deletedCount });
  } catch (e) {
    console.error("guardians remove error:", e);
    return res.status(500).json({ ok: false, message: "server error" });
  }
});

// =======================
// 서버 시작
// =======================
const port = process.env.PORT || 3000;

connectDB()
  .then(() => {
    app.listen(port, () => console.log("API listening on port", port));
  })
  .catch((err) => {
    console.error("Failed to start server:", err.message);
    process.exit(1);
  });
