package com.example.myapplication1;

public class SignupRequest {
    public String email;
    public String username;
    public String password;
    public boolean consent;

    public SignupRequest(String email,
                         String username,
                         String password,
                         boolean consent) {
        this.email = email;
        this.username = username;
        this.password = password;
        this.consent = consent;
    }
}
