package com.example.myapplication1;

public class HealthResponse {
    private boolean ok;
    public boolean isOk() { return ok; }
}
