package com.example.myapplication1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class SignActivity extends AppCompatActivity {

    private ApiService apiService;

    private EditText etEmail;
    private EditText etUsername;
    private EditText etPw;
    private EditText etPwCheck;
    private EditText etVerifyCode;

    private AppCompatButton btnVerifyRequest;
    private AppCompatButton btnVerifyCheck;
    private AppCompatButton btnSignupFinish;

    private boolean consent = false;
    private boolean emailVerified = false;
    private String verifiedEmail = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign);

        consent = getIntent().getBooleanExtra("consent", false);

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://10.0.2.2:3000/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        apiService = retrofit.create(ApiService.class);

        ImageView btnBack = findViewById(R.id.btn_back);

        etEmail = findViewById(R.id.et_sign_email);
        etUsername = findViewById(R.id.et_sign_id);      // 👉 아이디
        etPw = findViewById(R.id.et_sign_pw);
        etPwCheck = findViewById(R.id.et_sign_pw_check);
        etVerifyCode = findViewById(R.id.et_verify_code);

        btnVerifyRequest = findViewById(R.id.btn_verify_request);
        btnVerifyCheck = findViewById(R.id.btn_verify_check);
        btnSignupFinish = findViewById(R.id.btn_signup_finish);

        // 처음엔 인증 관련만 노출
        etVerifyCode.setVisibility(View.GONE);
        btnVerifyCheck.setVisibility(View.GONE);

        btnBack.setOnClickListener(v -> finish());

        // 1️⃣ 이메일 인증 요청
        btnVerifyRequest.setOnClickListener(v -> requestVerifyCode());

        // 2️⃣ 인증번호 확인
        btnVerifyCheck.setOnClickListener(v -> verifyCode());

        // 3️⃣ 회원가입 완료
        btnSignupFinish.setOnClickListener(v -> signup());
    }

    // =========================
    // 이메일 인증 요청
    // =========================
    private void requestVerifyCode() {
        String email = etEmail.getText().toString().trim();

        if (!consent) {
            Toast.makeText(this, "약관에 동의해야 합니다.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (email.isEmpty()) {
            Toast.makeText(this, "이메일을 입력해주세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        btnVerifyRequest.setEnabled(false);

        VerifyRequest req = new VerifyRequest(email, null);
        apiService.requestVerify(req).enqueue(new Callback<GenericResponse>() {
            @Override
            public void onResponse(Call<GenericResponse> call, Response<GenericResponse> response) {
                btnVerifyRequest.setEnabled(true);

                if (response.isSuccessful() && response.body() != null && response.body().isOk()) {
                    verifiedEmail = email;
                    etVerifyCode.setVisibility(View.VISIBLE);
                    btnVerifyCheck.setVisibility(View.VISIBLE);
                    Toast.makeText(SignActivity.this,
                            "인증번호가 이메일로 발송되었습니다.",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SignActivity.this,
                            "인증요청 실패 (" + response.code() + ")",
                            Toast.LENGTH_LONG).show();
                }
            }

            @Override
            public void onFailure(Call<GenericResponse> call, Throwable t) {
                btnVerifyRequest.setEnabled(true);
                Toast.makeText(SignActivity.this,
                        "서버 연결 실패: " + t.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    // =========================
    // 인증번호 확인
    // =========================
    private void verifyCode() {
        String code = etVerifyCode.getText().toString().trim();

        if (verifiedEmail == null) {
            Toast.makeText(this, "먼저 인증요청을 하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (code.length() != 6) {
            Toast.makeText(this, "인증번호 6자리를 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        VerifyRequest req = new VerifyRequest(verifiedEmail, code);
        apiService.verify(req).enqueue(new Callback<GenericResponse>() {
            @Override
            public void onResponse(Call<GenericResponse> call, Response<GenericResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isOk()) {
                    emailVerified = true;
                    Toast.makeText(SignActivity.this, "이메일 인증 완료", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SignActivity.this, "인증 실패", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GenericResponse> call, Throwable t) {
                Toast.makeText(SignActivity.this,
                        "서버 연결 실패: " + t.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }

    // =========================
    // 회원가입
    // =========================
    private void signup() {
        if (!emailVerified) {
            Toast.makeText(this, "이메일 인증을 먼저 완료하세요.", Toast.LENGTH_SHORT).show();
            return;
        }

        String username = etUsername.getText().toString().trim();
        String pw = etPw.getText().toString();
        String pw2 = etPwCheck.getText().toString();

        if (username.isEmpty() || pw.isEmpty()) {
            Toast.makeText(this, "아이디와 비밀번호를 입력하세요.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!pw.equals(pw2)) {
            Toast.makeText(this, "비밀번호가 일치하지 않습니다.", Toast.LENGTH_SHORT).show();
            return;
        }

        SignupRequest req = new SignupRequest(verifiedEmail, username, pw, true);
        apiService.signup(req).enqueue(new Callback<GenericResponse>() {
            @Override
            public void onResponse(Call<GenericResponse> call, Response<GenericResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().isOk()) {
                    Toast.makeText(SignActivity.this, "회원가입 완료!", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(SignActivity.this, MainActivity.class));
                    finish();
                } else {
                    Toast.makeText(SignActivity.this,
                            "회원가입 실패 (" + response.code() + ")",
                            Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<GenericResponse> call, Throwable t) {
                Toast.makeText(SignActivity.this,
                        "서버 연결 실패: " + t.getMessage(),
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
