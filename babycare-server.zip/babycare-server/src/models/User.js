const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    username: { type: String, required: true, unique: true },
    passwordHash: { type: String, required: true },
    verified: { type: Boolean, default: false },
    consentAt: { type: Date, required: true }, // 개인정보 동의 시각
  },
  { timestamps: true }
);

module.exports = mongoose.model("User", userSchema);
