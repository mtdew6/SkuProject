const express = require("express");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

const { connectDB } = require("./src/db");
const User = require("./src/models/User");
const LoginHistory = require("./src/models/LoginHistory");
const Guardian = require("./src/models/Guardian");
const EmailVerify = require("./src/models/EmailVerify");
const { sendVerifyMail } = require("./src/utils/mailer");

const app = express();
app.use(express.json());

// =======================
// JWT 설정
// =======================
const JWT_SECRET = process.env.JWT_SECRET || "dev-secret";
const ACCESS_EXPIRES_IN = "15m";
const REFRESH_EXPIRES_IN = "14d";

// =======================
// 인증 미들웨어
// =======================
function auth(req, res, next) {
  const header = req.headers.authorization || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : null;
  if (!token) return res.status(401).json({ ok: false });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.userId = decoded.userId;
    next();
  } catch {
    return res.status(401).json({ ok: false });
  }
}

// =======================
// ownerId 계산
// =======================
async function resolveOwnerIdForUser(userId) {
  const owner = await Guardian.findOne({ memberId: userId, role: "OWNER" });
  if (owner) return owner.ownerId;

  const sub = await Guardian.findOne({ memberId: userId, role: "SUB" });
  if (sub) return sub.ownerId;

  return userId;
}

// =======================
// Health
// =======================
app.get("/health", (req, res) => res.json({ ok: true }));

// =======================
// 1️⃣ 이메일 인증 요청 (User 생성 ❌)
// =======================
app.post("/auth/request-verify", async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ ok: false });

    const normalizedEmail = email.toLowerCase().trim();

    // 이미 가입된 이메일 차단
    if (await User.findOne({ email: normalizedEmail })) {
      return res.status(409).json({ ok: false, message: "email exists" });
    }

    // 기존 인증코드 제거
    await EmailVerify.deleteMany({ email: normalizedEmail });

    const code = Math.floor(100000 + Math.random() * 900000).toString();

    await EmailVerify.create({
      email: normalizedEmail,
      code,
      expiresAt: new Date(Date.now() + 10 * 60 * 1000),
    });

    await sendVerifyMail(normalizedEmail, code);
    res.json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false });
  }
});

// =======================
// 1️⃣ 이메일 인증 확인
// =======================
app.post("/auth/verify", async (req, res) => {
  try {
    const { email, code } = req.body;
    if (!email || !code) return res.status(400).json({ ok: false });

    const normalizedEmail = email.toLowerCase().trim();

    const record = await EmailVerify.findOne({
      email: normalizedEmail,
      code,
      expiresAt: { $gt: new Date() },
    });

    if (!record) {
      return res.status(400).json({ ok: false });
    }

    await EmailVerify.updateOne(
      { _id: record._id },
      { $set: { verified: true } }
    );

    res.json({ ok: true });
  } catch {
    res.status(500).json({ ok: false });
  }
});

// =======================
// 1️⃣ 회원가입 (인증 완료 후만 가능)
// =======================
app.post("/auth/signup", async (req, res) => {
  try {
    const { email, username, password, consent } = req.body;
    if (!email || !username || !password || consent !== true) {
      return res.status(400).json({ ok: false });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const normalizedUsername = username.toLowerCase().trim();

    const verified = await EmailVerify.findOne({
      email: normalizedEmail,
      verified: true,
    });

    if (!verified) {
      return res.status(403).json({ ok: false, message: "email not verified" });
    }

    if (await User.findOne({ username: normalizedUsername })) {
      return res.status(409).json({ ok: false, message: "username exists" });
    }

    const passwordHash = await bcrypt.hash(password, 10);

    const user = await User.create({
      email: normalizedEmail,
      username: normalizedUsername,
      passwordHash,
      verified: true,
      consentAt: new Date(),
    });

    await Guardian.create({
      ownerId: user._id,
      memberId: user._id,
      role: "OWNER",
    });

    await EmailVerify.deleteMany({ email: normalizedEmail });

    res.status(201).json({ ok: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ ok: false });
  }
});

// =======================
// 1️⃣ 로그인 (아이디만)
// =======================
app.post("/auth/login", async (req, res) => {
  const { username, password } = req.body;
  if (!username || !password) return res.status(400).json({ ok: false });

  const user = await User.findOne({ username: username.toLowerCase().trim() });
  if (!user) {
    await LoginHistory.create({ success: false, reason: "NO_USER" }).catch(() => {});
    return res.status(401).json({ ok: false });
  }

  const ok = await bcrypt.compare(password, user.passwordHash);
  if (!ok) {
    await LoginHistory.create({ userId: user._id, success: false, reason: "BAD_PASSWORD" }).catch(() => {});
    return res.status(401).json({ ok: false });
  }

  const accessToken = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: ACCESS_EXPIRES_IN });
  const refreshToken = jwt.sign({ userId: user._id }, JWT_SECRET, { expiresIn: REFRESH_EXPIRES_IN });

  await LoginHistory.create({ userId: user._id, success: true, reason: "OK" }).catch(() => {});

  res.json({ ok: true, accessToken, refreshToken });
});

// =======================
// 서버 시작
// =======================
const port = process.env.PORT || 3000;
connectDB().then(() => {
  app.listen(port, () => console.log("API listening on port", port));
});
